import type { ToolSchema } from "@/lib/types";

/**
 * The engine's real tools. These are executed by the ENGINE itself inside its
 * own `/api/chat` agent loop — the engine runs `run_command` on the engine
 * host, `web_search`/`fetch_page`/`crawl_site` on the engine's network, and
 * `generate_image`/`generate_voice` on the engine's GPU. Aether does NOT
 * re-implement these; it relays the engine's `/api/chat` agent loop.
 *
 * These schemas are kept as the canonical documentation of the engine's
 * capability surface. There is deliberately NO per-tool execution endpoint:
 * the engine executes tools internally, so there is nothing to proxy.
 */

export const REAL_TOOL_SCHEMAS: ToolSchema[] = [
  {
    name: "web_search",
    description: "Search the web. Returns ranked sources with titles, URLs and snippets (citations).",
    parameters: { type: "object", properties: { query: { type: "string" } }, required: ["query"] },
  },
  {
    name: "fetch_page",
    description: "Fetch one URL and return its readable text content.",
    parameters: { type: "object", properties: { url: { type: "string" } }, required: ["url"] },
  },
  {
    name: "crawl_site",
    description: "Crawl a site from a seed URL with depth and page limits; returns normalized sources.",
    parameters: {
      type: "object",
      properties: {
        url: { type: "string" },
        depth: { type: "number" },
        max_pages: { type: "number" },
      },
      required: ["url"],
    },
  },
  {
    name: "run_command",
    description:
      "Run an arbitrary shell command on the engine host (Ubuntu, internet ON, python3/pip/curl/git available, working dir /kaggle/working). Supports chained commands, pipes, redirects, scripts, package managers, git, compilers, runtimes, background jobs, networking tools, file operations, system inspection, and project tooling. Returns stdout, stderr and exit code.",
    parameters: {
      type: "object",
      properties: {
        command: { type: "string", description: "Full shell command line (e.g. 'ls -la | head', 'cd /tmp && ./build.sh')" },
        timeout: { type: "number", description: "seconds, default 60 max 150" },
      },
      required: ["command"],
    },
  },
  {
    name: "generate_image",
    description: "Generate a JPG image from a prompt. Returns the image artifact.",
    parameters: { type: "object", properties: { prompt: { type: "string" } }, required: ["prompt"] },
  },
  {
    name: "generate_voice",
    description: "Synthesize WAV speech/audio from text. Returns the audio artifact.",
    parameters: { type: "object", properties: { text: { type: "string" }, voice: { type: "string" } }, required: ["text"] },
  },
];
